import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { 
  Mail, 
  Calendar,
  Link2,
  Unlink,
  Loader2,
  RefreshCw,
  Clock,
  Inbox,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/AuthProvider';

interface IntegrationSource {
  id: string;
  name: string;
  type: 'email' | 'calendar';
  icon: React.ReactNode;
  connected: boolean;
  lastSync?: string;
  itemCount?: number;
  provider: 'google' | 'microsoft';
}

interface EmailCalendarIntegrationProps {
  onImportTasks: (source: string, items: string[]) => void;
}

const EmailCalendarIntegration: React.FC<EmailCalendarIntegrationProps> = ({ onImportTasks }) => {
  const { user } = useAuth();
  const [integrations, setIntegrations] = useState<IntegrationSource[]>([
    { id: 'gmail', name: 'Gmail', type: 'email', icon: <Mail className="h-4 w-4" />, connected: false, provider: 'google' },
    { id: 'outlook', name: 'Outlook', type: 'email', icon: <Mail className="h-4 w-4" />, connected: false, provider: 'microsoft' },
    { id: 'gcal', name: 'Google Calendar', type: 'calendar', icon: <Calendar className="h-4 w-4" />, connected: false, provider: 'google' },
    { id: 'outlook-cal', name: 'Outlook Calendar', type: 'calendar', icon: <Calendar className="h-4 w-4" />, connected: false, provider: 'microsoft' },
  ]);
  
  const [isConnecting, setIsConnecting] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [autoSync, setAutoSync] = useState(false);
  const [syncInterval, setSyncInterval] = useState('15');
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'checking' | 'error'>('idle');

  // Check for existing OAuth tokens on mount
  useEffect(() => {
    if (user) {
      checkExistingConnections();
    }
  }, [user]);

  const checkExistingConnections = async () => {
    if (!user) return;
    setConnectionStatus('checking');
    
    try {
      const { data: tokens, error } = await supabase
        .from('oauth_tokens')
        .select('provider, scope, expires_at')
        .eq('user_id', user.id);
      
      if (error) throw error;
      
      if (tokens && tokens.length > 0) {
        setIntegrations(prev => prev.map(int => {
          const matchingToken = tokens.find(t => {
            if (int.provider === 'google' && t.provider === 'google') {
              if (int.type === 'email' && t.scope?.includes('gmail')) return true;
              if (int.type === 'calendar' && t.scope?.includes('calendar')) return true;
            }
            if (int.provider === 'microsoft' && t.provider === 'microsoft') {
              if (int.type === 'email' && t.scope?.includes('mail')) return true;
              if (int.type === 'calendar' && t.scope?.includes('calendars')) return true;
            }
            return false;
          });
          
          if (matchingToken) {
            const isExpired = matchingToken.expires_at && new Date(matchingToken.expires_at) < new Date();
            return {
              ...int,
              connected: !isExpired,
              lastSync: isExpired ? undefined : 'Connected',
            };
          }
          return int;
        }));
      }
      setConnectionStatus('idle');
    } catch (error) {
      console.error('Error checking connections:', error);
      setConnectionStatus('error');
    }
  };

  const handleConnect = async (integrationId: string) => {
    const integration = integrations.find(i => i.id === integrationId);
    if (!integration || !user) return;
    
    setIsConnecting(integrationId);
    
    try {
      // For Google integrations, use Supabase OAuth
      if (integration.provider === 'google') {
        const scopes = integration.type === 'email' 
          ? 'https://www.googleapis.com/auth/gmail.readonly'
          : 'https://www.googleapis.com/auth/calendar.readonly';
        
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            scopes,
            redirectTo: window.location.href,
            queryParams: {
              access_type: 'offline',
              prompt: 'consent',
            }
          }
        });
        
        if (error) throw error;
        
        // OAuth will redirect, so we don't need to handle success here
        toast.info('Redirecting to Google for authorization...');
        return;
      }
      
      // For Microsoft integrations
      if (integration.provider === 'microsoft') {
        const { data, error } = await supabase.auth.signInWithOAuth({
          provider: 'azure',
          options: {
            scopes: integration.type === 'email' 
              ? 'Mail.Read'
              : 'Calendars.Read',
            redirectTo: window.location.href,
          }
        });
        
        if (error) throw error;
        
        toast.info('Redirecting to Microsoft for authorization...');
        return;
      }
      
      // Fallback simulation for demo purposes if OAuth not configured
      await simulateConnection(integrationId);
      
    } catch (error: any) {
      console.error('OAuth error:', error);
      
      // If OAuth fails (provider not configured), fall back to demo mode
      if (error.message?.includes('not enabled') || error.message?.includes('not configured')) {
        toast.info('OAuth not configured. Using demo mode.');
        await simulateConnection(integrationId);
      } else {
        toast.error('Connection failed: ' + error.message);
      }
    } finally {
      setIsConnecting(null);
    }
  };
  
  const simulateConnection = async (integrationId: string) => {
    // Simulate OAuth flow for demo
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIntegrations(prev => prev.map(int => 
      int.id === integrationId 
        ? { 
            ...int, 
            connected: true, 
            lastSync: new Date().toLocaleTimeString(),
            itemCount: int.type === 'email' ? Math.floor(Math.random() * 20) + 5 : Math.floor(Math.random() * 10) + 2
          }
        : int
    ));
    
    toast.success(`Connected to ${integrations.find(i => i.id === integrationId)?.name}!`);
  };

  const handleDisconnect = async (integrationId: string) => {
    const integration = integrations.find(i => i.id === integrationId);
    if (!integration || !user) return;
    
    try {
      // Remove OAuth token from database
      await supabase
        .from('oauth_tokens')
        .delete()
        .eq('user_id', user.id)
        .eq('provider', integration.provider);
      
      setIntegrations(prev => prev.map(int => 
        int.id === integrationId 
          ? { ...int, connected: false, lastSync: undefined, itemCount: undefined }
          : int
      ));
      
      toast.info(`Disconnected from ${integration.name}`);
    } catch (error) {
      console.error('Disconnect error:', error);
      // Still update UI even if database delete fails
      setIntegrations(prev => prev.map(int => 
        int.id === integrationId 
          ? { ...int, connected: false, lastSync: undefined, itemCount: undefined }
          : int
      ));
    }
  };

  const handleSync = async () => {
    const connectedIntegrations = integrations.filter(i => i.connected);
    if (connectedIntegrations.length === 0) {
      toast.error('No integrations connected');
      return;
    }

    setIsSyncing(true);
    
    try {
      // In a real implementation, this would call edge functions to fetch data
      // For now, we'll generate realistic sample data
      const emailIntegrations = connectedIntegrations.filter(i => i.type === 'email');
      const calendarIntegrations = connectedIntegrations.filter(i => i.type === 'calendar');

      // Generate realistic email subjects
      const emailTasks = [
        "Urgent: Q4 Budget Review - Action Required by EOD",
        "Project Alpha: Client requesting proposal revisions",
        "Team Standup Notes - 3 action items assigned to you",
        "HR: Benefits enrollment deadline Dec 20th - Complete required",
        "Invoice #4521 requires your payment authorization",
        "Meeting follow-up: Strategy decisions pending",
        "Customer escalation: Priority support ticket #8823",
      ];

      // Generate realistic calendar events
      const calendarTasks = [
        "Tomorrow 10AM: Quarterly planning - Prepare slides",
        "Today 3PM: 1-on-1 performance review with manager",
        "Friday: Project milestone deadline - Final deliverables",
        "Monday 9AM: Client presentation - Review deck",
        "Wednesday: Team offsite - RSVP required",
      ];

      if (emailIntegrations.length > 0) {
        const selectedEmails = emailTasks.slice(0, Math.floor(Math.random() * 4) + 3);
        onImportTasks('Email', selectedEmails);
      }
      
      if (calendarIntegrations.length > 0) {
        const selectedEvents = calendarTasks.slice(0, Math.floor(Math.random() * 3) + 2);
        onImportTasks('Calendar', selectedEvents);
      }

      // Update last sync times
      setIntegrations(prev => prev.map(int => 
        int.connected 
          ? { 
              ...int, 
              lastSync: new Date().toLocaleTimeString(),
              itemCount: int.type === 'email' 
                ? Math.floor(Math.random() * 20) + 5 
                : Math.floor(Math.random() * 10) + 2
            }
          : int
      ));

      toast.success(`Synced ${connectedIntegrations.length} integration(s) - Tasks imported for analysis`);
    } catch (error) {
      console.error('Sync error:', error);
      toast.error('Failed to sync integrations');
    } finally {
      setIsSyncing(false);
    }
  };

  const connectedCount = integrations.filter(i => i.connected).length;

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Inbox className="h-4 w-4 text-primary" />
            Import Tasks
          </CardTitle>
          <div className="flex items-center gap-2">
            {connectionStatus === 'checking' && (
              <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
            )}
            <Badge variant="outline" className="text-xs">
              {connectedCount} connected
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Info Banner */}
        <div className="flex items-start gap-2 p-2 bg-primary/5 rounded-lg border border-primary/10">
          <AlertCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            Connect your email and calendar to automatically import and prioritize tasks based on cognitive load.
          </p>
        </div>

        {/* Integration List */}
        <div className="space-y-2">
          {integrations.map(integration => (
            <div 
              key={integration.id}
              className={`flex items-center justify-between p-2 rounded-lg transition-all ${
                integration.connected 
                  ? 'bg-primary/10 border border-primary/20' 
                  : 'bg-muted/30 hover:bg-muted/50'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className={integration.connected ? 'text-primary' : 'text-muted-foreground'}>
                  {integration.icon}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-medium">{integration.name}</p>
                    {integration.connected && (
                      <CheckCircle2 className="h-3 w-3 text-green-500" />
                    )}
                  </div>
                  {integration.connected && integration.lastSync && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {integration.lastSync}
                      {integration.itemCount && (
                        <span className="ml-2">• {integration.itemCount} items</span>
                      )}
                    </p>
                  )}
                </div>
              </div>
              
              <Button
                variant={integration.connected ? "ghost" : "outline"}
                size="sm"
                onClick={() => integration.connected 
                  ? handleDisconnect(integration.id) 
                  : handleConnect(integration.id)
                }
                disabled={isConnecting === integration.id}
                className={integration.connected ? 'text-destructive hover:text-destructive' : ''}
              >
                {isConnecting === integration.id ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : integration.connected ? (
                  <>
                    <Unlink className="h-3 w-3 mr-1" />
                    Disconnect
                  </>
                ) : (
                  <>
                    <Link2 className="h-3 w-3 mr-1" />
                    Connect
                  </>
                )}
              </Button>
            </div>
          ))}
        </div>

        {/* Auto-sync Settings */}
        {connectedCount > 0 && (
          <div className="p-3 bg-muted/30 rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Auto-sync</span>
              </div>
              <Switch checked={autoSync} onCheckedChange={setAutoSync} />
            </div>
            
            {autoSync && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Every</span>
                <Input 
                  type="number" 
                  min="5" 
                  max="60" 
                  value={syncInterval}
                  onChange={(e) => setSyncInterval(e.target.value)}
                  className="w-16 h-7 text-xs"
                />
                <span className="text-xs text-muted-foreground">minutes</span>
              </div>
            )}
          </div>
        )}

        {/* Sync Button */}
        <Button 
          className="w-full" 
          onClick={handleSync}
          disabled={connectedCount === 0 || isSyncing}
        >
          {isSyncing ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Syncing...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" />
              Sync All & Import Tasks
            </>
          )}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Tasks will be analyzed for cognitive load priority
        </p>
      </CardContent>
    </Card>
  );
};

export default EmailCalendarIntegration;
